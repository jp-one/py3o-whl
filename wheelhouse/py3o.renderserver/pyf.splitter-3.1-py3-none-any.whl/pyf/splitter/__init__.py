# -*- encoding: utf-8 -*-
from pyf.splitter.inputsplitter import (
    tokenize, get_splitter, chain_splitters,
    get_input_item_flow, get_input_item_str_flow,
    EndOfFileError, InputSplitterError,
    input_item_separator,
)
